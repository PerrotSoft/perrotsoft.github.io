neron neron1 = new neron(the importance of neurons W float[] Wis,amount of neons int);
int w = neron1.setdata(value of neons float[]);
